package ch04;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Customer {
	
	private String account; //�Ȥ�b��
	private float balance;  //����b��l�B
	private float cost;   //����(ñ�b)��X
	private float deposit;  //����s��
	private float credit; //�H���B��
	
	//�غc�l
	public Customer(String account, float d, float e, float f, float g)
	{
		this.account = account;
		this.balance = d;
		this.cost = e;
		this.deposit = f;
		this.credit = g;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public float getDeposit() {
		return deposit;
	}

	public void setDeposit(float deposit) {
		this.deposit = deposit;
	}

	public float getCredit() {
		return credit;
	}

	public void setCredit(float credit) {
		this.credit = credit;
	}
	
	//�p��s�l�B
	public float countBalance() {
		float newBalance=0;
		newBalance = this.balance+this.cost-this.deposit;
		
		if(newBalance > this.credit) {
			//��ܶW�X�H���B�װT��
			 // create a jframe
		    JFrame frame = new JFrame("���~�T��");
		    
		    // show a joptionpane dialog using showMessageDialog
		    JOptionPane.showMessageDialog(frame,this.getAccount() + "��ܶW�X�H���B�װT��");
			return newBalance;
		}
		else {
			//�S���W�X�B��
			return newBalance;
		}
		
	}
	

}
