
package ch03;

public class PetrolPurchase {

	private String location;
	private String kind;
	private int litter;
	private double unitPrice;
	private double disscount;
	
	//�غc�l
	public PetrolPurchase(String loc, String k, int lit, double p, double d) {
		this.location = loc;
		this.kind = k;
		this.litter = lit;
		this.unitPrice = p;
		this.disscount =d;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public int getLitter() {
		return litter;
	}

	public void setLitter(int litter) {
		this.litter = litter;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getDisscount() {
		return disscount;
	}

	public void setDisscount(double disscount) {
		this.disscount = disscount;
	}
	
	//�p���ʶR���B
	double getPurchaseAmount() {
		double totalPrice =0;
		totalPrice= (this.litter *this.unitPrice) *this.disscount;
		return totalPrice;
	}
	
}
