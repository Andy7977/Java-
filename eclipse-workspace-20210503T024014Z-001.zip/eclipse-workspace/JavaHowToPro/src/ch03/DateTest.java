package ch03;

public class DateTest {
	
	public static void main(String[] args) {
		
		Date d= new Date(2021,4,15);
		
		
		System.out.println(d.displayDate());
		
	}

}
