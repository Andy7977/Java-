package ch03;

import java.util.Date;

public class HeartRatesTest {

	public static void main(String[] args) {

		HeartRates lisar = new HeartRates("Lisar", "�k", 1988, 9, 18);

		System.out.println("�m�W:" + lisar.getName());
		System.out.println("�ʧO:" + lisar.getSex());
		System.out.println("�X�ͦ~:" + lisar.getBirthday_year());
		System.out.println("�X�ͤ�:" + lisar.getBirthday_month());
		System.out.println("�X�ͤ�:" + lisar.getBirthday_day());

		System.out.println("�~��:" + lisar.getAge() + "��");

		System.out.println("�̤j�߷i�v:" + lisar.getMaxHeartRate());
		System.out.println("�зǤ߷i�v�d��:" + lisar.getHeartRateRange());

	}

}
