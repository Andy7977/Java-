package ch03;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class HeartRates {

	private String name;
	private String sex;
	private int birthday_year;
	private int birthday_month;
	private int birthday_day;

	// �غc�l
	public HeartRates(String myname, String mySex, int year, int month, int day) {
		this.name = myname;
		this.sex = mySex;
		this.birthday_year = year;
		this.birthday_month = month;
		this.birthday_day = day;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBirthday() {
		return String.valueOf(this.birthday_year) + "/" + String.valueOf(this.birthday_month) + "/"
				+ String.valueOf(this.birthday_day);
	}

	public int getBirthday_year() {
		return birthday_year;
	}

	public void setBirthday_year(int birthday_year) {
		this.birthday_year = birthday_year;
	}

	public int getBirthday_month() {
		return birthday_month;
	}

	public void setBirthday_month(int birthday_month) {
		this.birthday_month = birthday_month;
	}

	public int getBirthday_day() {
		return birthday_day;
	}

	public void setBirthday_day(int birthday_day) {
		this.birthday_day = birthday_day;
	}

	// �p��~��
	public int getAge() {
		int age = 0;
		int nowYear = Calendar.getInstance().get(Calendar.YEAR);

		return nowYear - this.birthday_year;
	}

	// �̤j�߷i�v
	public int getMaxHeartRate() {
		return 220 - getAge();
	}

	// �ؼФ߳Ųv
	String getHeartRateRange() {
		String range = "";
		float floor = 0;
		float ceil = 0;

		floor = (float) (getMaxHeartRate() * 0.5);
		ceil = (float) (getMaxHeartRate() * 0.85);

		range = "[" + String.valueOf(floor) + "-" + String.valueOf(ceil) + "]";

		return range;
	}
}
