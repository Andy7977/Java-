package ch03;

public class Account4 {
	private String name; // instance variable
	private double balance; // instance variable

// Account constructor that receives two parameters  
	public Account4(String name, double balance) {
		this.name = name; // assign name to instance variable name

		// validate that the balance is greater than 0.0; if it's not,
		// instance variable balance keeps its default initial value of 0.0
		if (balance > 0.0) // if the balance is valid
			this.balance = balance; // assign it to instance variable balance
	}

// method that deposits (adds) only a valid amount to the balance
	public void deposit(double depositAmount) {
		if (depositAmount > 0.0) // if the depositAmount is valid
			this.balance = this.balance + depositAmount; // add it to the balance
	}

// method returns the account balance
	public double getBalance() {
		return this.balance;
	}

// method that sets the name
	public void setName(String name) {
		this.name = name;
	}

// method that returns the name
	public String getName() {
		return name;
	}

	// ����
	public double withdraw(double withdrawAmount) {
		if (withdrawAmount > this.balance) {
			System.out.println("�l�B����!");
			return 0;
		} else {

			this.balance = this.balance - withdrawAmount;
			return withdrawAmount;
		}

	}

} // end class Account