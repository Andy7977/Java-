package ch03;

//Fig. 3.1: Account.java
//Account class that contains an name instance variable 
//and methods to set and get its value.

public class Account1 {
	private String myname; // instance variable

	// method to set the name in the object
	public void setName(String name1) {
		this.myname = name1; // store the name
	}

	// method to retrieve the name from the object
	public String getName() {
		return myname; // return value of name to caller
	}
}// end class Account
