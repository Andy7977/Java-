package ch02;

public class Welcome4 {

	// main method begins execution of Java application
	public static void main(String[] args) {
		System.out.printf("%s%n%s%n", "Welcome to", "Java Programming!");
	} // end method main

}
