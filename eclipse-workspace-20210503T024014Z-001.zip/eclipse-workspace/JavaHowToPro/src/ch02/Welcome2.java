package ch02;

public class Welcome2 {
	// main method begins execution of Java application
	   public static void main(String[] args)
	   {
	      System.out.print("Welcome to ");
	      System.out.println("Java Programming!");
	   } // end method main
}
