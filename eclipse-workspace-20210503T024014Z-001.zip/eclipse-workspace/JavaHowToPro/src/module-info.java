module javaHowToPro {
	requires java.desktop;
}